<?php
$MESS["T_BACK_TO_NEWS"] = "Назад к новостям";