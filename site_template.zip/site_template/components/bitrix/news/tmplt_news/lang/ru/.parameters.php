<?php
$MESS["T_IBLOCK_TMPLT_LIST"] = "Шаблон списка";
$MESS["T_IBLOCK_TMPLT_DETAIL"] = "Шаблон детальной информации";