<?php

$MESS ['FORM_BOTTOM_POLICY'] = "Нажимая &laquo;Отправить&raquo;, Вы&nbsp;подтверждаете, что
                ознакомлены, полностью согласны и&nbsp;принимаете условия &laquo;Согласия на&nbsp;обработку
                персональных данных&raquo;.";
$MESS ['FORM_SUBMIT'] = "Оставить заявку";
$MESS ['FORM_DATA_SUCCESS'] = "Отправлено";
$MESS ['FORM_DATA_ERROR'] = "Ошибка отправки";