<?
$arTemplate = array (
  'NAME' => 'empty',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>